rm(list = ls())

# array: 한가지 타입을 저장하는 3차원 이상의 배열
arr <- array(c(1:24), dim = c(2, 3, 4))
arr
arr[1, 1, 1]
arr[1, 1, 2]
arr[, , 1]
arr[1, , ]


# list: R 객체(object)들의 집합(collection)
name <- "아이티윌" # 원소가 1개인 벡터
num_vector <- c(10, 20, 30) # 원소가 3개인 숫자 벡터
num_matrix <- matrix(c(1:10), nrow = 5, ncol = 2)
my_list <- list(name, num_vector, num_matrix)
my_list




