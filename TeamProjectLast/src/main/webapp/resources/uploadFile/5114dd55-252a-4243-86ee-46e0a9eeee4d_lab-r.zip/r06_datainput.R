rm(list = ls())

# 외부 파일에서 data frame을 만드는 방법
# 1. csv(comma separated values) 파일
df_exam1 <- read.csv("csv_exam.csv")
df_exam1
str(df_exam1) # str(): structure(자료 구조)
summary(df_exam1) # summary(): 통계 요약
head(df_exam1)


# 2. 엑셀(xls, xlsx) 파일에서 data frame 만들기
# 엑셀 파일을 사용하기 위해서는 외부 패키지가 필요
# 외부 패키지를 설치
install.packages("readxl")

# 현재 사용가능한 패키지들의 목록
search()

# 외부 패키지 설치 후에는 메모리에 로드
library(readxl)
search()

df_exam2 <- read_excel("excel_exam.xlsx")
df_exam2
str(df_exam2)
head(df_exam2)
tail(df_exam2)
View(df_exam2)
summary(df_exam2)
summary(df_exam2$math)
sd(df_exam2$math)





