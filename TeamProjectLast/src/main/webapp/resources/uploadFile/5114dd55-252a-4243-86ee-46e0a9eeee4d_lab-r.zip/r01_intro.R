# R에서의 주석
x <- 100 # 변수 x에 값 100을 저장
x
y <- 200 # 변수 y에 값 200을 저장
x + y
x - y
x * y

weight <- c(4.4, 5.3, 7.2, 5.2, 8.5, 7.3, 6.0, 10.4, 10.2)
weight
summary(weight) # 통계 요약 정보
mean(weight) # 평균
sd(weight) #SD(Standard Deviation): 표준편차

weight + 1

