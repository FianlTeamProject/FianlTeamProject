# data frame: 각 열(column)마다 다른 타입의 데이터를 
# 저장할 수 있는 테이블 모양의 자료 타입
# R에서 가장 많이 사용하는 자료 타입

patient_id <- 1:4
patient_id

age <- c(25, 34, 28, 52)
age

type <- c("Type1", "Type2", "Type2", "Type1")
type

status <- c("Poor", "Improved", "Excellent", "Poor")
status

df_patient <- data.frame(patient_id, age, type, status)
df_patient
str(df_patient) # str(): 자료 타입의 구조
head(df_patient, n = 2) # head(): 자료의 처음 몇 건만 출력
tail(df_patient, n = 2) # tail(): 자료의 마지막 몇 건만 출력

# data frame에서 특정 컬럼(변수)의 내용만 확인
df_patient$patient_id
df_patient$age


# R을 설치할 때 함께 포함된 예제 데이터 프레임
str(mtcars)
mtcars
head(mtcars, n = 3) # n의 기본값 = 6
summary(mtcars) # summary(): 통계 요약 정보

# mtcars 데이터 프레임에서 연비(mpg)만 확인
mtcars$mpg # 벡터(vector)
mtcars["mpg"] # 데이터 프레임(data frame)
mtcars[c("mpg", "cyl", "wt")]

plot(mtcars$wt, mtcars$mpg)








