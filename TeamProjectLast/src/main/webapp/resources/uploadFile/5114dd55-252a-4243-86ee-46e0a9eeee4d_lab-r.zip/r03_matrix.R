rm(list = ls())

# matrix: 한가지 타입을 저장할 수 있는 2차원 배열
m1 <- matrix(c(1:6), nrow = 3, ncol = 2)
m1
m2 <- matrix(c(1:6), nrow = 3, ncol = 2, byrow = TRUE)
m2

rnames <- c("행1", "행2", "행3")
cnames <- c("열1", "열2")
cnames
r_c_names <- list(rnames, cnames)
r_c_names
m3 <- matrix(c(1:6), nrow = 3, ncol = 2, 
             byrow = FALSE, dimnames = r_c_names)
m3
m3[2, 1] # 2행 1열의 원소
m3[1,] # 1행의 모든 원소
m3[, 2] # 2열의 모든 원소
m3["행2", "열1"] 
# 행/열에 이름이 있는 경우 인덱스뿐 만 아니라, 
# 행/열의 이름으로도 검색 가능
m3["행1",]
m3[, "열2"]


