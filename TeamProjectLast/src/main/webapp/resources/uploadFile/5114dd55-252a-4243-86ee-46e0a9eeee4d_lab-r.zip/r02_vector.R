x <- 1
y <- 2
z <- 3
ls()

rm(list = ls())

# vector: 한가지 타입의 데이터를 한개 이상 저장할 수 있는
# 1차원 배열 형태의 데이터 타입
x <- 1 # 원소의 갯수가 1개인 vector
x <- 1:10 # 1씩 증가하는 연속적인 숫자
x

# 숫자들을 저장하는 벡터
# c(): combine 함수 - 매개변수들로 이루어진 벡터를 생성
num_vector <- c(1, 3, 4, 10, 15)
num_vector
num_vector[1] # R에서 인덱스는 1부터 시작
num_vector[3]

# 논리값(boolean)들을 저장하는 벡터
bool_vector <- c(TRUE, FALSE, FALSE, TRUE)
bool_vector[4]

# 문자(열)을 저장하는 벡터
text_vector <- c("one", "two", "three")
text_vector[2]

v1 <- c(1, 2, TRUE, FALSE)
v1

v2 <- c(123, "two", FALSE)
v2

# R에서의 자동 형변환: 유연성이 더 높은 타입으로 자동 형변환
# 유연성: 논리값 < 정수 < 실수 < 문자열
v3 <- c(TRUE, 1, 1.1, "1.1")
v3

v4 <- seq(1, 5) # v4 <- 1:5
v4

v5 <- seq(1, 10, 2)
v5

v6 <- seq(10, 1, -2)
v6

v7 <- rep(1, 10)
v7

v8 <- rep("배고파요~", 5)
v8

v9 <- seq(1, 20)
v9[2] # 벡터 v9의 인덱스 2번 원소
v9[c(1, 2)] # v9[1], v9[2]
v9[seq(2, 10, 2)] # v9[2], v9[4], v9[6], v9[8], v9[10]
v9[11:20]



