rm(list = ls())

## 데이터 프레임 가공하기
# 1. 데이터 프레임 생성
df_raw <- data.frame(var1 = c(1, 2, 1),
                     var2 = c(2, 3, 2)) 
df_raw # 데이터 프레임 내용 확인
str(df_raw) # 데이터 프레임의 구조 확인

# 데이터 가공에 필요한 패키지(dplyr)를 설치
install.packages("dplyr")

# 설치한 패키지를 메모리에 로드
library(dplyr)
search() # 메모리에 로드됐는 지 확인

# 데이터 프레임의 변수(컬럼) 이름을 변경
df_raw <- rename(df_raw, v1 = var1)
df_raw
df_new <- rename(df_raw, v2 = var2)
df_new


## 기존 데이터 프레임에 새로운 변수(컬럼) 추가
df_score <- data.frame(id = c(1, 2, 3),
                       kor = c(90, 85, 100),
                       eng = c(75, 95, 65))
df_score

# df_score 데이터 프레임에 sum 변수(컬럼)을 추가
df_score$sum <- df_score$kor + df_score$eng
df_score

# df_score 데이터 프레임에 avg 변수(컬럼)을 추가
df_score$avg <- df_score$sum / 2
df_score

# df_score 데이터 프레임에서 avg 값이
# 90점 이상이면 Pass, 그렇지 않으면 Fail을 
# grade 변수(컬럼)에 저장
df_score$grade <- 
  ifelse(df_score$avg >= 90, "Pass", "Fail")
df_score
# String result = (avg >= 90) ? "pass" : "fail";

df_score2 <- data.frame(avg = c(77, 99, 85, 64, 100))
df_score2
# grade 변수(컬럼)을 만들고,
# 90점 이상이면, A
# 80점 이상이면, B,
# 70점 이상이면, C
# 나머지는 F
df_score2$grade <-
  ifelse(df_score2$avg >= 90, "A", 
         ifelse(df_score2$avg >= 80, "B", 
                ifelse(df_score2$avg >= 70, "C", "F")))
df_score2


## ggplot2 패키지 설치
install.packages("ggplot2")
library(ggplot2) # 패키지를 메모리에 로드
search() # 메모리에 로드된 패키지 확인

# ggplot2에 포함된 mpg 데이터 프레임을 사용
?mpg # help 창에서 도움말 확인
str(mpg) # mpg 데이터 프레임의 구조
head(mpg)
tail(mpg)

# 원본 데이터를 가공하기 위해서 객체(변수)에 복사
df_mpg <- as.data.frame(mpg)
head(df_mpg)

# 1. df_mpg 변수 중에서 cty -> city, hwy -> highway
# 변수 이름을 변경
df_mpg <- rename(df_mpg, city = cty, highway = hwy)
head(df_mpg)

# 2. df_mpg 데이터 프레임에 avg 변수를 추가하고,
# 도심 연비(city)와 고속도로 연비(highway)의 평균값을 저장
df_mpg$avg <- (df_mpg$city + df_mpg$highway) / 2
head(df_mpg)

# 3. df_mpg 데이터 프레임의 avg 변수의 평균(mean)을 계산
mean_mpg <- mean(df_mpg$avg)
mean_mpg

# 4. df_mpg 데이터 프레임에 test 변수를 추가하고,
# avg가  3번에서 계산한 평균보다 크면 "pass",
# 그렇지 않으면 "fail"이라고 저장
df_mpg$test <-
  ifelse(df_mpg$avg > mean_mpg, "pass", "fail")
head(df_mpg)
tail(df_mpg)

# table(): 분포표를 만들어주는 함수
table(df_mpg$test)
qplot(df_mpg$test)








