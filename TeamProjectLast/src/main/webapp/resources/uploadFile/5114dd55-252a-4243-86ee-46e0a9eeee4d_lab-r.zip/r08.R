rm(list = ls())

## 조건에 맞는 데이터 추출하기
# dplyr 패키지의 함수들을 사용
# install.packages("dplyr") # 패키지 설치
# library(dplyr) # 패키지를 메모리에 로드
search()

df_exam <- read.csv("csv_exam.csv")
str(df_exam)

# 1반(class == 1)인 학생들의 데이터만 추출
# df_exam$class
# df_exam$math
df_exam %>% filter(class == 1)
# %>%: 파이프 연산자(Ctrl + Shift + M)
# dplyr 패키지의 함수들은 데이터 프레임의 이름 없이 
# 변수 이름만을 사용하는 경우가 대부분

# 1반이 아닌 학생들의 데이터를 추출
df_exam %>% filter(class != 1)

# 1반, 2반 학생들의 데이터를 추출
df_exam %>% filter(class == 1 | class == 2)

# 1, 2, 3반 학생들의 데이터를 추출
df_exam %>% filter(class %in% c(1:3))

# 수학 점수가 80점 이상인 학생들의 데이터 추출
df_exam %>% filter(math >= 80)

# 수학 점수가 80점 이상이고,
# 영어 점수도 80점 이상인 학생들의 데이터 추출
df_exam %>% filter(math >= 80 & english >= 80)


# 데이터 프레임에서 특정 변수로 추출: select()
df_exam %>% select(math)

# 학생 id와 수학 점수(math)를 추출
df_exam %>% select(id, math)

# class를 제외한 나머지 변수들 정보를 모두 추출
df_exam %>% select(id, math, english, science)
df_exam %>% select(-class)

# 1반 학생들의 id와 수학 점수를 추출
df_exam %>% 
  filter(class == 1) %>% 
  select(id, math)

# df_exam %>% select(id, math) %>% filter(class == 1)

head(df_exam)
df_exam %>% select(id, math) %>% head


## 정렬: arrange()
# 수학 점수 오름차순 정렬
df_exam %>% arrange(math)

# 수학 점수 내림차순 정렬
df_exam %>% arrange(desc(math))

# 반(class)별로, 수학점수 오름차순 정렬
df_exam %>% arrange(class, math)

## 데이터 프레임에 변수를 추가: mutate()
# df_exam$total <- 
#   df_exam$math + df_exam$english + df_exam$science
df_exam %>% 
  mutate(total = (math + english + science))

# 총점(total)과 평균(avg) 컬럼을 추가
df_exam %>% 
  mutate(total = (math + english + science),
         avg = (math + english + science) / 3)

# df_exam 데이터 프레임에
# 총점(total), 평균(avg) 변수를 추가하고,
# 총점의 내림차순 정렬을 해서 출력
df_exam %>% 
  mutate(total = (math + english + science),
         avg = (math + english + science) / 3) %>% 
  arrange(desc(total))


## 그룹별(group_by()) 요약(summarise()) 정보를 추출
df_exam %>% summarise(mean_math = mean(math))
mean(df_exam$math)

df_exam %>% 
  group_by(class) %>% 
  summarise(mean_math = mean(math))

# 반(class)별로 세 과목 각각의 평균을 추출
df_exam %>% 
  group_by(class) %>% 
  summarise(m_math = mean(math),
            m_eng = mean(english),
            m_sci = mean(science))


## 데이터 합치기
# 컬럼을 합치기: left_join()
# 행을 합치기: bind_rows()
df_mid = data.frame(id = c(1:5),
                    mid = c(60, 70, 80, 100, 90))
df_mid

df_final <- data.frame(id = c(1:5),
                       final = c(70, 55, 90, 0, 88))
df_final

df_mid_final <- left_join(df_mid, df_final, by = "id")
df_mid_final

df_temp1 <- data.frame(id = c(1:5),
                       test = c(10, 20, 30, 100, 50))
df_temp1

df_temp2 <- data.frame(id = c(6:10),
                       test = c(66, 77, 88, 11, 22))
df_temp2

df_test <- bind_rows(df_temp1, df_temp2)
df_test


# 학생들의 성적 데이터 프레임 확인
df_exam

# 선생님의 이름을 저장하는 데이터 프레임을 생성
df_teacher <- data.frame(class = c(1:5),
                         teacher = c("김", "이", "박", "오", "노"))
df_teacher

df_new <- left_join(df_exam, df_teacher, by = "class")
df_new


## 연습 문제
search()
View(mpg) # ggplot2::mpg 데이터 프레임
# 1) mpg 데이터 프레임을 제조사(manufacturer)별로 그룹화
# -> group_by()
# 2) class 중에서 "suv"만 추출
# -> filter()
# 3) avg 컬럼 추가 - 도심/고속도로 연비의 평균 저장
# -> mutate()
# 4) avg의 평균값을 summarise() 함수로 추출

df_mpg <- mpg %>% 
  group_by(manufacturer) %>% 
  filter(class == "suv") %>% 
  mutate(avg = (cty + hwy) / 2) %>% 
  summarise(mean_mpg = mean(avg))
View(df_mpg)

mpg %>% 
  group_by(manufacturer) %>% 
  summarise(mean(cty))





